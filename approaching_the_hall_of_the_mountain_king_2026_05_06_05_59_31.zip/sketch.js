// music
let Grieg;

// treasure
let x, y, size1;

function preload() {
  Grieg = loadSound('assets/griegSmaller.mp3');
}

function setup() {
  createCanvas(400, 300);
  
  // play Grieg
  Grieg.play(); 

}

function draw() {
  // timing to animate the circles to the music

// start 650  

if (millis() > 137550){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('137550', 50, 50);
  }   

else if (millis() > 136900){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('136900', 50, 50);
  }   

else if (millis() > 136250){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('136250', 50, 50);
  }   

else if (millis() > 135600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('135600', 50, 50);
  }   

else if (millis() > 134950){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('134950', 50, 50);
  }   

else if (millis() > 134300){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('134300', 50, 50);
  }   

else if (millis() > 133650){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('133650', 50, 50);
  }   

else if (millis() > 133000){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('133000', 50, 50);
  }   

else if (millis() > 132350){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('132350', 50, 50);
  }   


else if (millis() > 131700){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('131700', 50, 50);
  }   

else if (millis() > 131050){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('131050', 50, 50);
  }   

else if (millis() > 130400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('130400', 50, 50);
  }   

else if (millis() > 129750){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('129750', 50, 50);
  }   


else if (millis() > 129100){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('129100', 50, 50);
  }   

else if (millis() > 128450){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('128450', 50, 50);
  }   

else if (millis() > 127800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('127800', 50, 50);
  }   

else if (millis() > 127150){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('127150', 50, 50);
  }   
  
  else if (millis() > 126500){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('126500', 50, 50);
  }   

else if (millis() > 125850){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('125850', 50, 50);
  }   

else if (millis() > 125200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('125200', 50, 50);
  }   

else if (millis() > 124550){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('124550', 50, 50);
  }   

else if (millis() > 123900){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('123900', 50, 50);
  }   

else if (millis() > 123250){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('123250', 50, 50);
  }   

else if (millis() > 122600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('122600', 50, 50);
  }   

else if (millis() > 121950){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('121950', 50, 50);
  }   

else if (millis() > 121300){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('121300', 50, 50);
  }   



else if (millis() > 120650){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('120650', 50, 50);
  }   


else if (millis() > 120000){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('120000', 50, 50);
  }   


else if (millis() > 119350){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('119350', 50, 50);
  }   


else if (millis() > 118700){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('118700', 50, 50);
  }   


else if (millis() > 118050){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('118050', 50, 50);
  }   



else if (millis() > 117400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('117400', 50, 50);
  }   


else if (millis() > 116750){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('116750', 50, 50);
  }   


else if (millis() > 116100){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('116100', 50, 50);
  }   


else if (millis() > 115450){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('115450', 50, 50);
  }   


else if (millis() > 114800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('114800', 50, 50);
  }   


else if (millis() > 114150){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('114150', 50, 50);
  }   


else if (millis() > 113500){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('113500', 50, 50);
  }   


else if (millis() > 112850){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('112850', 50, 50);
  }   


else if (millis() > 112200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('112200', 50, 50);
  }   

else if (millis() > 111550){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('111550', 50, 50);
  }   


else if (millis() > 110900){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('110900', 50, 50);
  }   


else if (millis() > 110250){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('110250', 50, 50);
  }   


else if (millis() > 109600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('109600', 50, 50);
  }   


else if (millis() > 108950){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('108950', 50, 50);
  }   

// end 650, start 700
  
else if (millis() > 108300){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('108300', 50, 50);
  }   

else if (millis() > 107600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('107600', 50, 50);
  }   


else if (millis() > 106900){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('106900', 50, 50);
  }   


else if (millis() > 106200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('106200', 50, 50);
  }   


else if (millis() > 105500){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('105500', 50, 50);
  }   


else if (millis() > 104800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('104800', 50, 50);
  }   

else if (millis() > 104100){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('104100', 50, 50);
  }   

// end 700, start 650

else if (millis() > 103400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('103400', 50, 50);
  }   
    

else if (millis() > 102750){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('102750', 50, 50);
  }     

else if (millis() > 102100){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('102100', 50, 50);
  }     

else if (millis() > 101450){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('101450', 50, 50);
  }     

else if (millis() > 100800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('100800', 50, 50);
  }     
  
else if (millis() > 100150){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('100150', 50, 50);
  }   

else if (millis() > 99500){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('99500', 50, 50);
  }   

else if (millis() > 98850){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('98850', 50, 50);
  } 
  
else if (millis() > 98200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('98200', 50, 50);
  }   

else if (millis() > 97550){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('97550', 50, 50);
  } 

else if (millis() > 96900){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('96900', 50, 50);
  }   

else if (millis() > 96250){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('96250', 50, 50);
  } 
    
else if (millis() > 95600){
//pop this one!
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('95600', 50, 50);
  }   

else if (millis() > 94950){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('94950', 50, 50);
  } 

else if (millis() > 94300){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('94300', 50, 50);
  } 

// end 650, start 700   
  
else if (millis() > 93600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('93600', 50, 50);
  }  

else if (millis() > 92900){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('92900', 50, 50);
  }    

else if (millis() > 92200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('92200', 50, 50);
  }  
 
else if (millis() > 91500){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('91500', 50, 50);
  }   
  
else if (millis() > 90800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('90800', 50, 50);
  }    
    
else if (millis() > 90100){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('90100', 50, 50);
  }    
    
else if (millis() > 89400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('89400', 50, 50);
  }    
  
else if (millis() > 88700){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('88700', 50, 50);
  }      
  
else if (millis() > 88000){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('88000', 50, 50);
  }      
  
else if (millis() > 87300){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('87300', 50, 50);
  }    


// end 700, start 800 
  
else if (millis() > 86600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('86600', 50, 50);
  }    
  
  
else if (millis() > 85800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('85800', 50, 50);
  }    
  
  
else if (millis() > 85000){
//pop this one!
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('85000', 50, 50);
  }    
  
  
else if (millis() > 84200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('84200', 50, 50);
  }    
  
  
else if (millis() > 83400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('83400', 50, 50);
  }    
  
  
else if (millis() > 82600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('82600', 50, 50);
  }    
    
else if (millis() > 81800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('81800', 50, 50);
  }    
    
else if (millis() > 81000){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('81000', 50, 50);
  }    
  
else if (millis() > 80200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('80200', 50, 50);
  }    
    
else if (millis() > 79400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('79400', 50, 50);
  }    

  
else if (millis() > 78600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('78600', 50, 50);
  }    

else if (millis() > 77800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('77800', 50, 50);
  }    
  
else if (millis() > 77000){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('77000', 50, 50);
  }    

else if (millis() > 76200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('76200', 50, 50);
  }    

else if (millis() > 75400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('75400', 50, 50);
  }    
  
else if (millis() > 74600){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('74600', 50, 50);
  }    
  
else if (millis() > 73800){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('73800', 50, 50);
  }      

else if (millis() > 73000){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('73000', 50, 50);
  }    

else if (millis() > 72200){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('72200', 50, 50);
}    


// end 800, start 850  
  
else if (millis() > 71400){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill ('white');
    text('71450', 50, 50);
  }      

// end 850, start 900  
  
else if (millis() > 70550){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill ('white');
    text('70550', 50, 50);
  }    
  
else if (millis() > 69650){
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill ('white');
    text('69650', 50, 50);
  }    
 
else if (millis() > 68750){
    drawGynt();
    fill('black')
    rect(30,30,80,30)
    fill ('white');
    text('68750', 50, 50);
  }    
  
else if (millis() > 67850){
    drawGynt();
    fill('black')
    rect(30,30,80,30)
    fill ('white');
    text('67850', 50, 50);
  }    
  
else if (millis() > 66950){
    drawGynt();
    fill('black')
    rect(30,30,80,30)
    fill ('white');
    text('66950', 50, 50);
  }    


// end 900, start 925  
  
else if (millis() > 66050){
    gyntColumns12();
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('66050', 50, 50);
  }      
  
else if (millis() > 65125){
//pop this one!
    gyntColumns12();
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('65125', 50, 50);
  }    
  
else if (millis() > 64200){
    gyntColumns12();
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('64200', 50, 50);
  }    

else if (millis() > 63275){
    gyntColumns12();
    drawGynt();
    fill('black');
    rect(30,30,80,30);
    fill('white');
    text('63275', 50, 50);
  }    

// end 925, start 950   
  
else if (millis() > 62350){
    gyntColumns13();
    drawGynt();
  }    
    
else if (millis() > 61400){
    gyntColumns12();
    drawGynt();
  }    
  
else if (millis() > 60450){
    gyntColumns11();
    drawGynt();
  }  

else if (millis() > 59500){
    gyntColumns10();
    drawGynt();
  }  
  
else if (millis() > 58550){
    gyntColumns9();
    drawGynt();
  }  
  
else if (millis() > 57600){
    gyntColumns8();
    drawGynt();
  }      
  
else if (millis() > 56650){
    gyntColumns7();
    drawGynt();
  }      
  
else if (millis() > 55700){
    gyntColumns6();
    drawGynt();
  }    
    
else if (millis() > 54750){
    gyntColumns5();
    drawGynt();
  }    
  
else if (millis() > 53800){
    gyntColumns4();
    drawGynt();
  }    
  
else if (millis() > 52850){
    gyntColumns3();
    drawGynt();
  }    
  
else if (millis() > 51900){
    gyntColumns2();
    drawGynt();
  }  
  
else if (millis() > 50950){
    gyntColumns1();
    drawGynt();
  }  

// end 1000, start 950
  
else if (millis() > 50000){
    gyntHall9();
    drawGynt();
  }
        
else if (millis() > 49000){
    gyntHall8();
    drawGynt();
  }
  
else if (millis() > 48000){
    gyntHall7();
    drawGynt();
  }
  
else if (millis() > 47000){
    gyntHall6();
    drawGynt();
  }
  
else if (millis() > 46000){
    gyntHall5();
    drawGynt();
  }
  
  else if (millis() > 45000){
    gyntHall4();
    drawGynt();
  }
  
  else if (millis() > 44000){
    gyntHall3();
    drawGynt();
  }  
  
  else if (millis() > 43000){
    gyntHall2();
    drawGynt();
  }

// end 1000, start 1100
  
  
 else if (millis() > 41900){
    gyntHall1();
    drawGynt();
  }

  else if (millis() > 40800){
    gyntEntrance23();
    drawGynt();
  }

  else if (millis() > 39700){
    gyntEntrance22();
    drawGynt();
  }
    
  else if (millis() > 38600){
    gyntEntrance21();
    drawGynt();
  }

  else if (millis() > 37500){
    gyntEntrance20();
    drawGynt();
  }
  
  else if (millis() > 36400){
    gyntEntrance19();
    drawGynt();
  }

  else if (millis() > 35300){
    gyntEntrance18();
    drawGynt();
  }

  else if (millis() > 34200){
    gyntEntrance17();
    drawGynt();
  }

  else if (millis() > 33100){
    gyntEntrance16();
    drawGynt();
  }
  
  else if (millis() > 32000){
    gyntEntrance15();
    drawGynt();
  }
  
  else if (millis() > 30900){
    gyntEntrance14();
    drawGynt();
  }

  
  else if (millis() > 29800){
    gyntEntrance13();
    drawGynt();
  }
  
  else if (millis() > 28600){
    gyntEntrance12();
    drawGynt();
  }
  
  else if (millis() > 27400){
    gyntEntrance11();
    drawGynt();
  }
  
  else if (millis() > 26200){
    gyntEntrance10();
    drawGynt();
  }
  
  else if (millis() > 25000){
    gyntEntrance9();
    drawGynt();
  }
  
  else if (millis() > 23800){
    gyntEntrance8();
    drawGynt();
  }
  
   else if (millis() > 22600){
    gyntEntrance7();
    drawGynt();
  }
  
  else if (millis() > 21400){
    gyntEntrance6();
    drawGynt();
  }
  
  else if (millis() > 20200){
    gyntEntrance5();
    drawGynt();
  }
  
  else if (millis() > 19000){
    gyntEntrance4();
    drawGynt();
  }
  
  else if (millis() > 17800){
    gyntEntrance3();
    drawGynt();
  }
  
  else if (millis() > 16600){
    gyntEntrance2();
    drawGynt();
  }
  
  else if (millis() > 15400){
    gyntEntrance1();
    drawGynt();
  }
  
  else if (millis() > 14200){
    gyntMountain7();
    drawGynt();
  }
  
  else if (millis() > 13000){
    gyntMountain6();
    drawGynt();
  }
  
   else if (millis() > 11800){
     gyntMountain5();
     drawGynt();
   }
  
    else if (millis() > 10600){
      gyntMountain4();
      drawGynt();
    }
  
    else if (millis() > 9400){
      gyntMountain3();
      drawGynt();
    }
  
    else if (millis() > 8200){
      gyntMountain2();
      drawGynt();
    }
    else if (millis() > 7000) {
        gyntMountain1();
        drawGynt();
    }
    else if (millis() > 6000) {
        drawGynt();
    }
    else {
        background ("lightblue");
    } 

}


function drawGynt(){  
    fill("grey");
    circle(200, 295, 15)  
}

function drawGlint(){
  // designating variables
  x = random(-50,450);
  y = random(-50,350);
  size1 = random(1, 20);

  fill("yellow");
  // glint coordinates
  for (let i=0; i<50;i++){
    circle(x, y, size1);
  }
}

function gyntMountain1(){
    fill("#836a44");
    circle(200, 300, 35);
    circle(178, 300, 15);
    circle(222, 300, 15);
    filter(BLUR, 1/2)
}

function gyntMountain2(){
    fill("#836a44");
    circle(200, 295, 55);
    circle(165, 300, 30);
    circle(235, 300, 30);
      filter(BLUR, 1/2);
}

function gyntMountain3(){
    fill("#836a44");
    circle(200, 285, 55); 
    circle(200, 300, 70);
    circle(155, 300, 40);
    circle(245, 300, 40);
    filter(BLUR, 1/2);
}

function gyntMountain4(){
    fill("#836a44");
    circle(200, 270, 65); 
    circle(200, 290, 90);
    
    circle(140, 300, 75);
    circle(260, 300, 75);
    
    circle(145, 305, 40);
    circle(255, 305, 40);
    
    circle(310, 305, 25);
    circle(90, 305, 25);
    filter(BLUR, 1/2);
}

function gyntMountain5(){
    fill("#836a44");
    circle(200, 220, 60); 
    
    circle(200, 240, 85); 
    
    circle(200, 280, 135);
    
    circle(130, 290, 100);
    circle(270, 290, 100);
    
    circle(120, 300, 50);
    circle(280, 300, 50);
    
    circle(335, 300, 35);
    circle(65, 300, 35);
    filter(BLUR, 1/2);
}

function gyntMountain6(){
    fill("#836a44");
    circle(200, 190, 60); 
    
    circle(200, 215, 90); 
    
    circle(200, 270, 160);
    
    circle(120, 285, 120);
    circle(280, 285, 120);
    
    circle(105, 290, 60);
    circle(295, 290, 60);
    
    circle(355, 295, 40);
    circle(45, 295, 40);
    filter(BLUR, 1/2);

}

function gyntMountain7(){

    fill("#836a44");
    circle(200, 145, 60);    
    
   // fill("blue");
    circle(200, 170, 95);    

//    fill("green");
    circle(200, 230, 175);
    circle(200, 230, 95);
    circle(120, 230, 95);
    circle(280, 230, 95);

    circle(340, 270, 75);
    circle(60, 270, 75);

    circle(380, 300, 45);
    circle(20, 300, 45);
    
    circle(200, 210, 90); 
    
    circle(200, 260, 160);
    
    circle(110, 285, 125);
    circle(290, 285, 125);
    
    circle(95, 290, 60);
    circle(305, 290, 60);
    
    circle(365, 295, 40);
    circle(35, 295, 40);        
    
    filter(BLUR, 1/2);  
}

function gyntEntrance1(){
    fill("#836a44");
    
    circle(200, 130, 55);    
    
   // fill("blue");
    circle(200, 160, 100);    

//    fill("green");
    circle(200, 215, 175);

//    fill("pink")
    circle(105, 215, 95);
    circle(295, 215, 95);
    
//    fill("blue")
    circle(345, 270, 105);
    circle(55, 270, 105);

//    fill("green")
    circle(400, 300, 45);
    circle(0, 300, 45);
    
    circle(200, 205, 100); 
    
    circle(200, 255, 170);
    
    circle(100, 280, 130);
    circle(300, 280, 130);
    
//    fill("blue")
    circle(85, 290, 70);
    circle(315, 290, 70);
    
//    fill("magenta")
    circle(380, 295, 50);
    circle(20, 295, 50);
    
    fill("#614e30");
    circle(200, 300, 25);
    
    filter(BLUR, 1/2);
}

function gyntEntrance2(){
    fill("#836a44");
    
    circle(200, 120, 50);    
    
   // fill("blue");
    circle(200, 150, 100);    

//    fill("green");
    circle(200, 205, 180);

//    fill("pink")
    circle(100, 210, 105);
    circle(300, 210, 105);
    
//    fill("blue")
    circle(355, 265, 110);
    circle(45, 265, 110);

//    fill("pink")
    circle(200, 200, 105); 
    circle(200, 250, 175);

//    fill("magenta")
    circle(90, 280, 135);
    circle(310, 280, 135);
    
//    fill("blue")
    circle(75, 290, 75);
    circle(325, 290, 75);
    
//    fill("green")
    circle(395, 295, 50);
    circle(5, 295, 50);
    
    fill("#614e30");
    circle(200, 295, 30);
        filter(BLUR, 1/2);

}

function gyntEntrance3(){

    fill("#836a44");
    
    circle(200, 110, 50);    
    
   // fill("blue");
    circle(200, 140, 100);    

//    fill("green");
    circle(200, 200, 195);
    
//    fill("pink")
    circle(95, 205, 110);
    circle(305, 205, 110);
    
//    fill("blue")
    circle(360, 260, 120);
    circle(40, 260, 120);

//    fill("pink")
    circle(200, 190, 110); 
    circle(200, 250, 200);

//    fill("magenta")
    circle(80, 275, 140);
    circle(320, 275, 140);
    
//    fill("blue")
    circle(65, 290, 80);
    circle(335, 290, 80);
    
//    fill("green")
    circle(410, 295, 55);
    circle(-10, 295, 55);
  
    fill("#614e30");
    circle(200, 290, 40);
    filter(BLUR, 1/2);

}

function gyntEntrance4(){
    fill("#836a44");
    
    circle(200, 100, 45);    
    
   // fill("blue");
    circle(200, 130, 95);    

//    fill("green");
    circle(200, 195, 200);
    
//    fill("pink")
    circle(90, 200, 110);
    circle(310, 200, 110);
    
//    fill("blue")
    circle(375, 255, 125);
    circle(25, 255, 125);

//    fill("magenta")
    circle(200, 180, 110); 
    circle(200, 245, 205);

//    fill("green")
    circle(70, 270, 145);
    circle(330, 270, 145);
    
//    fill("slateblue")
    circle(55, 290, 85);
    circle(345, 290, 85);
    
//    fill("green")
    circle(425, 295, 55);
    circle(-25, 295, 55);
  
    fill("#614e30");
    circle(200, 285, 50);
    filter(BLUR, 1/2);

}

function gyntEntrance5(){  

    fill("#836a44");
    
    circle(200, 95, 45);    
    
   // fill("blue");
    circle(200, 125, 95);    

//    fill("green");
    circle(200, 190, 200);
    
//    fill("pink")
    circle(85, 195, 115);
    circle(315, 195, 115);
    
//    fill("blue")
    circle(380, 250, 130);
    circle(20, 250, 130);

//    fill("magenta")
    circle(200, 170, 115); 
    circle(200, 240, 210);

//    fill("green")
    circle(60, 270, 150);
    circle(340, 270, 150);
    
//    fill("slateblue")
    circle(40, 285, 90);
    circle(360, 285, 90);
    
    fill("#614e30");
    circle(200, 285, 70);
 
    fill("#362e1c");
    circle(200, 290, 30);
    
    filter(BLUR, 1/2);
}

function gyntEntrance6(){
    fill("#836a44");
    
    circle(200, 85, 45);    
    
   // fill("blue");
    circle(200, 115, 95);    

//    fill("green");
    circle(200, 185, 205);
    
//    fill("pink")
    circle(80, 190, 120);
    circle(320, 190, 120);
    
//    fill("blue")
    circle(390, 235, 135);
    circle(10, 235, 135);

//    fill("magenta")
    circle(200, 165, 120); 
    circle(200, 235, 230);

//    fill("green")
    circle(30, 265, 165);
    circle(370, 265, 165);
    
//    fill("slateblue")
    circle(5, 280, 90);
    circle(395, 280, 90);
    
    fill("#614e30");
    circle(200, 280, 100);
    
    fill("#362e1c");
    circle(200, 290, 45);
    
    filter(BLUR, 1/2);

}

function gyntEntrance7(){
    fill("#836a44");
    
    circle(200, 70, 50);    
    
   // fill("blue");
    circle(200, 120, 145);    

//    fill("green");
    circle(200, 170, 210);
    
//    fill("pink")
    circle(80, 170, 120);
    circle(320, 170, 120);
    
//    fill("blue")
    circle(420, 210, 140);
    circle(-20, 210, 140);

//    fill("magenta")
    circle(200, 155, 130); 
    circle(200, 240, 250);

//    fill("green")
    circle(10, 265, 175);
    circle(390, 265, 175);
    
//    fill("slateblue")
    circle(-20, 275, 95);
    circle(420, 275, 95);

    fill("#614e30");
    circle(200, 275, 120);
    
    fill("#362e1c");
    circle(200, 285, 60);
    
    fill("#262424")
    circle(200, 295, 20);
    
    filter(BLUR, 1/2);

}

function gyntEntrance8(){
  
    fill("#836a44");
    
   // fill("blue");
    circle(200, 105, 140);    

//    fill("green");
    circle(200, 160, 225);
    
//    fill("pink")
    circle(70, 165, 125);
    circle(330, 165, 125);
    
//    fill("blue")
    circle(430, 205, 145);
    circle(-30, 205, 145);

//    fill("magenta")
    circle(200, 145, 135); 
    circle(200, 235, 270);

//    fill("green")
    circle(-5, 260, 190);
    circle(405, 260, 190);
    
//    fill("slateblue")
    circle(-40, 270, 100);
    circle(440, 270, 100);

    fill("#614e30");
    circle(200, 270, 130);
    
    fill("#362e1c");
    circle(200, 285, 70);
    
    fill("#262424")
    circle(200, 290, 30);
    
    filter(BLUR, 1/2);

}

function gyntEntrance9(){
  fill("#836a44");
    
   // fill("blue");
    circle(200, 80, 120);    

//    fill("green");
    circle(200, 140, 225);
    
//    fill("pink")
    circle(70, 150, 125);
    circle(330, 150, 125);
    
//    fill("blue")
    circle(430, 190, 145);
    circle(-30, 190, 145);

//    fill("magenta")
    circle(200, 130, 135); 
    circle(200, 235, 290);

//    fill("green")
    circle(-25, 255, 210);
    circle(425, 255, 210);
    
    fill("#614e30");
    circle(200, 265, 150);
    
    fill("#362e1c");
    circle(200, 280, 100);
    
    fill("#262424")
    circle(200, 285, 50);
    
    fill("black")
    circle(200, 295, 20);
    
    filter(BLUR, 1/2);

}

function gyntEntrance10(){
    fill("#836a44");
    
   // fill("blue");
    circle(200, 50, 90);    

//    fill("green");
    circle(200, 115, 205);
    
//    fill("pink")
    circle(70, 130, 140);
    circle(330, 130, 140);
    
//    fill("blue")
    circle(450, 160, 145);
    circle(-50, 160, 145);

//    fill("magenta")
    circle(200, 110, 145); 
    circle(200, 235, 340);

//    fill("green")
    circle(-50, 245, 215);
    circle(450, 245, 215);
    
    fill("#614e30");
    circle(200, 255, 200);
    
    fill("#362e1c");
    circle(200, 270, 120);
    
    fill("#262424")
    circle(200, 275, 70);
    
    fill("black")
    circle(200, 285, 30);
    
    filter(BLUR, 1/2);
}

function gyntEntrance11(){

    fill("#836a44");
    
   // fill("blue");
    circle(200, 45, 90);    

//    fill("green");
    circle(200, 105, 200);
    
//    fill("pink")
    circle(85, 100, 120);
    circle(315, 100, 120);
    
//    fill("blue")
    circle(415, 145, 155);
    circle(-15, 145, 155);

//    fill("magenta")
    circle(200, 90, 120); 
    circle(200, 235, 360);

//    fill("green")
    circle(-60, 230, 240);
    circle(460, 230, 240);
    
    fill("#614e30");
    circle(200, 245, 235);
    
    fill("#362e1c");
    circle(200, 255, 145);
    
    fill("#262424")
    circle(200, 270, 95);
    
    fill("black")
    circle(200, 280, 45);
    
    filter(BLUR, 1/2);
}

function gyntEntrance12(){
    fill("#836a44");

//    fill("green");
    circle(200, 95, 195);
    
//    fill("pink")
    circle(90, 85, 110);
    circle(310, 85, 110);
    
//    fill("blue")
    circle(390, 140, 155);
    circle(10, 140, 155);

//    fill("magenta")
    circle(200, 80, 110); 
    circle(200, 230, 380);

//    fill("green")
    circle(-90, 230, 260);
    circle(490, 230, 260);
    
    fill("#614e30");
    circle(200, 230, 250);
    
    fill("#362e1c");
    circle(200, 250, 155);
    
    fill("#262424")
    circle(200, 265, 105);
    
    fill("black")
    circle(200, 280, 50);
    
    filter(BLUR, 1/2);
}

function gyntEntrance13(){
    fill("#836a44");
    
//    fill("green");
    circle(200, 80, 185);
    
//    fill("pink")
    circle(120, 60, 100);
    circle(280, 60, 100);
    
//    fill("blue")
    circle(350, 120, 155);
    circle(50, 120, 155);

//    fill("magenta")
    circle(200, 60, 100); 
    circle(200, 220, 400);

//    fill("green")
    circle(-110, 235, 280);
    circle(510, 235, 280);
    
    fill("#614e30");
    circle(200, 220, 280);
    
    fill("#362e1c");
    circle(200, 230, 185);
    
    fill("#262424")
    circle(200, 245, 135);
    
    fill("black")
    circle(200, 265, 80);
    
    filter(BLUR, 1/2);
}

function gyntEntrance14(){
    fill("#836a44");
        
//    fill("pink")
    circle(125, 50, 105);
    circle(275, 50, 105);
    
//    fill("blue")
    circle(340, 100, 170);
    circle(60, 100, 170);

//    fill("magenta")
    circle(200, 220, 450);

//    fill("green")
    circle(-130, 235, 280);
    circle(530, 235, 280);
    
    fill("#614e30");
    circle(200, 200, 300);
    
    fill("#362e1c");
    circle(200, 220, 205);
    
    fill("#262424")
    circle(200, 240, 145);
    
    fill("black")
    circle(200, 260, 90);
    
    filter(BLUR, 1/2);
}

function gyntEntrance15(){
    fill("#836a44");
            
//    fill("blue")
    circle(335, 80, 185);
    circle(65, 80, 185);

//    fill("magenta")
    circle(200, 220, 500);    

    fill("#614e30");
    circle(200, 180, 340);
    
    fill("#362e1c");
    circle(200, 200, 245);
    
    fill("#262424")
    circle(200, 240, 155);
    
    fill("black")
    circle(200, 260, 100);
    
    filter(BLUR, 1/2);
}

function gyntEntrance16(){
    fill("#836a44");

//    fill("magenta")
    circle(200, 190, 550);    

    fill("#614e30");
    circle(200, 165, 385);
    
    fill("#362e1c");
    circle(200, 190, 300);
    
    fill("#262424")
    circle(200, 225, 185);
    
    fill("black");
    circle(200, 255, 110);
    
    filter(BLUR, 1/2);
}

function gyntEntrance17(){
    fill("#836a44");
    circle(200, 235, 650);
    fill("#614e30");
    circle(200, 155, 425);
    fill("#362e1c");
    circle(200, 180, 345);
    fill("#262424");
    circle(200, 210, 235);
    fill("black");
    circle(200, 245, 140);
          filter(BLUR, 1/2);
}

function gyntEntrance18(){
    fill("#836a44");
    circle(200, 235, 700);
    fill("#614e30");
    circle(200, 160, 490);
    fill("#362e1c");
    circle(200, 170, 380);
    fill("#262424");
    circle(200, 190, 285);
    fill("black");
    circle(200, 230, 165);
          filter(BLUR, 1/2)
}

function gyntEntrance19(){
    fill("#362e1c");
    circle(200, 145, 520);
    fill("#262424");
    circle(200, 160, 385);
    fill("black");
    circle(200, 200, 290);
    filter(BLUR, 1/2)
}

function gyntEntrance20(){
    fill("#362e1c");
    circle(200, 145, 520);
    fill("#262424");
    circle(200, 160, 485);
    fill("black");
    circle(200, 190, 370);
    filter(BLUR, 1/2)
}

function gyntEntrance21(){
    fill("#262424");
    circle(200, 160, 515);
    fill("black");
    circle(200, 180, 400);
    filter(BLUR, 1/2)
}

function gyntEntrance22(){
    fill("#262424");
    circle(200, 160, 515);
    fill("black");
    circle(200, 170, 500);
    filter(BLUR, 1/2)
}

function gyntEntrance23(){
    background ("black")
}

function gyntHall1(){
    background ("black")
    fill("#c5270f"); 
    circle(200, 300, 25);
    filter(BLUR, 5)
}

function gyntHall2(){
      background ("black")
    fill("#c5270f"); 
    circle(200, 300, 35);
    fill("#de2d12")
    circle(200, 300, 25);
    filter(BLUR, 5)
}

function gyntHall3(){
      background ("black")
    fill("#c5270f"); 
    circle(200, 300, 55);
    fill("#de2d12")
    circle(200, 300, 45);
    fill("#f23113")
    circle(200, 300, 35);
    filter(BLUR, 5)
}

function gyntHall4(){
      background ("black")
    fill("#c5270f"); 
    circle(200, 295, 65);
    fill("#de2d12")
    circle(200, 295, 55);
    fill("#f23113")
    circle(200, 295, 45);
    fill("#f5600a")
    circle(200, 295, 25);
    filter(BLUR, 5)
}

function gyntHall5(){
      background ("black")
    fill("#c5270f"); 
    circle(200, 295, 85);
    fill("#de2d12")
    circle(200, 295, 75);
    fill("#f23113")
    circle(200, 295, 65);
    fill("#f5600a")
    circle(200, 295, 45);
    fill("#f78400")
    circle(200, 295, 25);
    filter(BLUR, 5)
}

function gyntHall6(){
    background ("black")
    fill("#c5270f"); 
    circle(200, 290, 125);
    fill("#de2d12")
    circle(200, 290, 105);
    fill("#f23113")
    circle(200, 290, 85);
    fill("#f5600a")
    circle(200, 290, 65);
    fill("#f78400")
    circle(200, 290, 45);
    fill("#fa9702")
    circle(200, 290, 25);
    filter(BLUR, 5)
}

function gyntHall7(){
      background ("black")
    fill("#c5270f"); 
    circle(200, 285, 155);
    fill("#de2d12")
    circle(200, 285, 125);
    fill("#f23113")
    circle(200, 285, 105);
    fill("#f5600a")
    circle(200, 285, 85);
    fill("#f78400")
    circle(200, 285, 65);
    fill("#fa9702")
    circle(200, 285, 45);
    fill("#faa702")
    circle(200, 285, 25);
    filter(BLUR, 5)
}

function gyntHall8(){
      background ("black")
    fill("#801606"); 
    circle(200, 275, 225);
    fill("#c5270f"); 
    circle(200, 280, 185);
    fill("#de2d12")
    circle(200, 280, 145);
    fill("#f23113")
    circle(200, 280, 125);
    fill("#f5600a")
    circle(200, 280, 105);
    fill("#f78400")
    circle(200, 280, 85);
    fill("#fa9702")
    circle(200, 280, 65);
    fill("#faa702")
    circle(200, 280, 45);
    fill("#fab802")
    circle(200, 285, 25);
    filter(BLUR, 5)
}

function gyntHall9(){
      background ("#540101")
    fill("#801606"); 
    circle(200, 250, 400);
    fill("#c5270f"); 
    circle(200, 250, 320);
    fill("#de2d12")
    circle(200, 270, 290);
    fill("#f23113")
    circle(200, 270, 245);
    fill("#f5600a")
    circle(200, 270, 175);
    fill("#f78400")
    circle(200, 270, 115);
    fill("#fa9702")
    circle(200, 270, 95);
    fill("#faa702") 
    circle(200, 275, 75);
    fill("#fab802")
    circle(200, 275, 55);
    filter(BLUR, 5)
}

function gyntColumns1(){
    background ("#540101")
    fill("#801606"); 
    circle(200, 250, 440);
    fill("#c5270f"); 
    circle(200, 250, 360);
    fill("#de2d12")
    circle(200, 270, 310);
    fill("#f23113")
    circle(200, 270, 265);
    fill("#f5600a")
    circle(200, 270, 195);
    fill("#f78400")
    circle(200, 270, 125);
    fill("#fa9702")
    circle(200, 270, 115);
    fill("#faa702") 
    circle(200, 275, 95);
    fill("#fab802")
    circle(200, 275, 75);
    filter(BLUR, 5);
   
    fill("cornsilk");
    circle(190, 295, 6);
    fill("#262626");
    circle(187, 295, 5);
    fill("cornsilk");
    circle(210, 295, 6);
    fill("#262626");
    circle(213, 295, 5);
    filter(BLUR, 2);
}

function gyntColumns2(){
      background ("#540101")
    fill("#801606"); 
    circle(200, 250, 480);
    fill("#c5270f"); 
    circle(200, 250, 400);
    fill("#de2d12")
    circle(200, 270, 330);
    fill("#f23113")
    circle(200, 270, 285);
    fill("#f5600a")
    circle(200, 270, 215);
    fill("#f78400")
    circle(200, 270, 145);
    fill("#fa9702")
    circle(200, 270, 135);
    fill("#faa702") 
    circle(200, 275, 115);
    fill("#fab802")
    circle(200, 275, 95);
    filter(BLUR, 5);
    
    //
    
    fill("cornsilk");
    circle(185, 295, 8);
    fill("#262626");
    circle(182, 295, 7);

    fill("cornsilk");
    circle(215, 295, 8);
    fill("#262626");
    circle(218, 295, 7);
    
    filter(BLUR, 2);
}

function gyntColumns3(){  

    background ("#540101")
    fill("#801606"); 
    circle(200, 250, 510);
    fill("#c5270f"); 
    circle(200, 250, 440);
    fill("#de2d12")
    circle(200, 270, 350);
    fill("#f23113")
    circle(200, 270, 315);
    fill("#f5600a")
    circle(200, 270, 235);
    fill("#f78400")
    circle(200, 270, 165);
    fill("#fa9702")
    circle(200, 270, 155);
    fill("#faa702") 
    circle(200, 275, 135);
    fill("#fab802")
    circle(200, 275, 115);
    filter(BLUR, 5);
    
    //
    
    fill("cornsilk");
    circle(190, 295, 6);
    
    fill("#262626");
    circle(187, 295, 5);
    
    fill("cornsilk");
    circle(210, 295, 6);
    
    fill("#262626");
    circle(213, 295, 5);
        
    //
    //
    
    fill("cornsilk");
    circle(170, 297, 10);
    fill("#262626");
    circle(167, 297, 9);
    
    fill("cornsilk");
    circle(170, 290, 6);
    fill("#262626");
    circle(167, 290, 5);
    
    fill("cornsilk");
    circle(230, 297, 10);
    fill("#262626");
    circle(233, 297, 9);
    
    fill("cornsilk");
    circle(230, 290, 6);
    fill("#262626");
    circle(233, 290, 5);
    
    filter(BLUR, 2);
}

function gyntColumns4(){

    background ("#540101")
    fill("#801606"); 
    circle(200, 250, 550);
    fill("#c5270f"); 
    circle(200, 250, 480);
    fill("#de2d12")
    circle(200, 270, 370);
    fill("#f23113")
    circle(200, 270, 335);
    fill("#f5600a")
    circle(200, 270, 255);
    fill("#f78400")
    circle(200, 270, 185);
    fill("#fa9702")
    circle(200, 270, 175);
    fill("#faa702") 
    circle(200, 275, 155);
    fill("#fab802")
    circle(200, 275, 135);
    filter(BLUR, 5);
    
    //
    
    
    fill("cornsilk");
    circle(185, 295, 8);
    fill("#262626");
    circle(182, 295, 7);

    fill("cornsilk");
    circle(215, 295, 8);
    fill("#262626");
    circle(218, 295, 7);
    
    //
    //
    

    fill("cornsilk");
    circle(165, 295, 10);
    fill("#262626");
    circle(162, 295, 9);
    
    fill("cornsilk");
    circle(165, 288, 6);
    fill("#262626");
    circle(162, 288, 5);
    
    fill("cornsilk");
    circle(235, 295, 10);
    fill("#262626");
    circle(238, 295, 9);
    
    fill("cornsilk");
    circle(235, 288, 6);
    fill("#262626");
    circle(238, 288, 5);
    
    //
    //
    //
    
      fill("cornsilk");
    circle(135, 293, 20);
    fill("#262626");
    circle(132, 293, 19);
    
    fill("cornsilk");
    circle(135, 278, 10);
    fill("#262626");
    circle(132, 278, 9);
    
    fill("cornsilk");
    circle(135, 269, 6);
    fill("#262626"); 
    circle(132, 269, 5);
    
    
    fill("cornsilk");
    circle(265, 293, 20);
    fill("#262626");
    circle(268, 293, 19);
    
    fill("cornsilk");
    circle(265, 278, 10);
    fill("#262626");
    circle(268, 278, 9);
    
    fill("cornsilk");
    circle(265, 269, 6);
    fill("#262626");
    circle(268, 269, 5);
    
    filter(BLUR, 2);
}

function gyntColumns5(){
    background ("#540101")
    fill("#801606"); 
    circle(200, 250, 590);
    fill("#c5270f"); 
    circle(200, 250, 520);
    fill("#de2d12")
    circle(200, 270, 390);
    fill("#f23113")
    circle(200, 270, 355);
    fill("#f5600a")
    circle(200, 270, 275);
    fill("#f78400")
    circle(200, 270, 205);
    fill("#fa9702")
    circle(200, 270, 195);
    fill("#faa702") 
    circle(200, 275, 175);
    fill("#fab802")
    circle(200, 275, 155);
    filter(BLUR, 5);
    
    //
    
    fill("cornsilk");
    circle(190, 295, 6);
    
    fill("#262626");
    circle(187, 295, 5);
    
    fill("cornsilk");
    circle(210, 295, 6);
    
    fill("#262626");
    circle(213, 295, 5);
    
    //
    //
    
    fill("cornsilk");
    circle(170, 295, 10);
    fill("#262626");
    circle(167, 295, 9);
    
    fill("cornsilk");
    circle(170, 288, 6);
    fill("#262626");
    circle(167, 288, 5);
    
    fill("cornsilk");
    circle(230, 295, 10);
    fill("#262626");
    circle(233, 295, 9);
    
    fill("cornsilk");
    circle(230, 288, 6);
    fill("#262626");
    circle(233, 288, 5);
    
    //
    //
    //

    fill("cornsilk");
    circle(140, 293, 20);
    fill("#262626");
    circle(137, 293, 19);
    
    fill("cornsilk");
    circle(140, 278, 10);
    fill("#262626");
    circle(137, 278, 9);
    
    fill("cornsilk");
    circle(140, 269, 6);
    fill("#262626"); 
    circle(137, 269, 5);
    
    
    fill("cornsilk");
    circle(260, 293, 20);
    fill("#262626");
    circle(263, 293, 19);
    
    fill("cornsilk");
    circle(260, 278, 10);
    fill("#262626");
    circle(263, 278, 9);
    
    fill("cornsilk");
    circle(260, 269, 6);
    fill("#262626");
    circle(263, 269, 5);
  
    //
    //
    //
    //

    fill("cornsilk");
    circle(100, 288, 30);
    fill("#262626");
    circle(97, 288, 29);
    
    fill("cornsilk");
    circle(100, 268, 20);
    fill("#262626");
    circle(97, 268, 19);
    
    fill("cornsilk");
    circle(100, 253, 10);
    fill("#262626");
    circle(97, 253, 9);
    
    fill("cornsilk");
    circle(100, 244, 6);
    fill("#262626"); 
    circle(97, 244, 5);
    

      fill("cornsilk");
    circle(300, 288, 30);
    fill("#262626");
    circle(303, 288, 29);    
    
    fill("cornsilk");
    circle(300, 268, 20);
    fill("#262626");
    circle(303, 268, 19);
    
    fill("cornsilk");
    circle(300, 253, 10);
    fill("#262626");
    circle(303, 253, 9);
    
    fill("cornsilk");
    circle(300, 244, 6);
    fill("#262626");
    circle(303, 244, 5);    
    
    filter(BLUR, 2);
}

function gyntColumns6(){
    background ("#540101")
    fill("#c5270f"); 
    circle(200, 250, 640);
    fill("#de2d12")
    circle(200, 270, 470);
    fill("#f23113")
    circle(200, 270, 405);
    fill("#f5600a")
    circle(200, 270, 325);
    fill("#f78400")
    circle(200, 270, 265);
    fill("#fa9702")
    circle(200, 270, 255);
    fill("#faa702") 
    circle(200, 275, 235);
    fill("#fab802")
    circle(200, 275, 215);
    filter(BLUR, 5);
    
    //
    
    fill("cornsilk");
    circle(185, 295, 8);
    fill("#262626");
    circle(182, 295, 7);

    fill("cornsilk");
    circle(215, 295, 8);
    fill("#262626");
    circle(218, 295, 7);
    
    //
    //

    fill("cornsilk");
    circle(165, 295, 10);
    fill("#262626");
    circle(162, 295, 9);
   
    fill("cornsilk");
    circle(165, 288, 6);
    fill("#262626");
    circle(162, 288, 5);
    
    fill("cornsilk");
    circle(235, 295, 10);
    fill("#262626");
    circle(238, 295, 9);
    
    fill("cornsilk");
    circle(235, 288, 6);
    fill("#262626");
    circle(238, 288, 5);
    
    //
    //
    //
    
      fill("cornsilk");
    circle(135, 293, 20);
    fill("#262626");
    circle(132, 293, 19);
    
    fill("cornsilk");
    circle(135, 278, 10);
    fill("#262626");
    circle(132, 278, 9);
    
    fill("cornsilk");
    circle(135, 269, 6);
    fill("#262626"); 
    circle(132, 269, 5);    
    
      fill("cornsilk");
    circle(265, 293, 20);
    fill("#262626");
    circle(268, 293, 19);
    
    fill("cornsilk");
    circle(265, 278, 10);
    fill("#262626");
    circle(268, 278, 9);
    
    fill("cornsilk");
    circle(265, 269, 6);
    fill("#262626");
    circle(268, 269, 5);
  
    //
    //
    //
    //
    

      fill("cornsilk");
    circle(95, 288, 30);
    fill("#262626");
    circle(92, 288, 29);
    
      fill("cornsilk");
    circle(95, 268, 20);
    fill("#262626");
    circle(92, 268, 19);
    
    fill("cornsilk");
    circle(95, 253, 10);
    fill("#262626");
    circle(92, 253, 9);
    
    fill("cornsilk");
    circle(95, 244, 6);
    fill("#262626"); 
    circle(92, 244, 5);    


      fill("cornsilk");
    circle(305, 288, 30);
    fill("#262626");
    circle(308, 288, 29);    
    
    fill("cornsilk");
    circle(305, 268, 20);
    fill("#262626");
    circle(308, 268, 19);
    
    fill("cornsilk");
    circle(305, 253, 10);
    fill("#262626");
    circle(308, 253, 9);
    
    fill("cornsilk");
    circle(305, 244, 6);
    fill("#262626");
    circle(308, 244, 5);

    //
    //
    //
    //
    //
    

      fill("cornsilk");
    circle(35, 278, 50);
    fill("#262626");
    circle(32, 278, 49);
    
    fill("cornsilk");
    circle(35, 241, 30);
    fill("#262626");
    circle(32, 241, 29);
    
    fill("cornsilk");
    circle(35, 218, 20);
    fill("#262626");
    circle(32, 218, 19);
    
    fill("cornsilk");
    circle(35, 203, 10);
    fill("#262626");
    circle(32, 203, 9);
    
    fill("cornsilk");
    circle(35, 194, 6);
    fill("#262626"); 
    circle(32, 194, 5);    


      fill("cornsilk");
    circle(365, 278, 50);
    fill("#262626");
    circle(368, 278, 49);    

    fill("cornsilk");
    circle(365, 241, 30);
    fill("#262626");
    circle(368, 241, 29);    
    
    fill("cornsilk");
    circle(365, 218, 20);
    fill("#262626");
    circle(368, 218, 19);
    
    fill("cornsilk");
    circle(365, 203, 10);
    fill("#262626");
    circle(368, 203, 9);
    
    fill("cornsilk");
    circle(365, 194, 6);
    fill("#262626");
    circle(368, 194, 5);
    
    filter(BLUR, 2);
}

function gyntColumns7(){
    background ("#540101")
    fill("#c5270f"); 
    circle(200, 250, 660);
    fill("#de2d12")
    circle(200, 270, 490);
    fill("#f23113")
    circle(200, 270, 425);
    fill("#f5600a")
    circle(200, 270, 345);
    fill("#f78400")
    circle(200, 270, 285);
    fill("#fa9702")
    circle(200, 270, 275);
    fill("#faa702") 
    circle(200, 275, 255);
    fill("#fab802")
    circle(200, 275, 235);
    filter(BLUR, 5);
  
    //

    fill("cornsilk");
    circle(190, 295, 6);
    
    fill("#262626");
    circle(187, 295, 5);
    
    fill("cornsilk");
    circle(210, 295, 6);
    
    fill("#262626");
    circle(213, 295, 5);
    
    
    //
    //
    
    fill("cornsilk");
    circle(170, 295, 9);
    fill("#262626");
    circle(167, 295, 8);
   
    fill("cornsilk");
    circle(170, 288, 6);
    fill("#262626");
    circle(167, 288, 5);
    
    fill("cornsilk");
    circle(230, 295, 9);
    fill("#262626");
    circle(233, 295, 8);
    
    fill("cornsilk");
    circle(230, 288, 6);
    fill("#262626");
    circle(233, 288, 5);

    
    //
    //
    //
    

      fill("cornsilk");
    circle(140, 293, 19);
    fill("#262626");
    circle(137, 293, 18);
    
    fill("cornsilk");
    circle(140, 278, 9);
    fill("#262626");
    circle(137, 278, 8);
    
    fill("cornsilk");
    circle(140, 269, 6);
    fill("#262626"); 
    circle(137, 269, 5);
    
    
      fill("cornsilk");
    circle(260, 293, 19);
    fill("#262626");
    circle(263, 293, 18);
    
    fill("cornsilk");
    circle(260, 278, 9);
    fill("#262626");
    circle(263, 278, 8);
    
    fill("cornsilk");
    circle(260, 269, 6);
    fill("#262626");
    circle(263, 269, 5);
  
    //
    //
    //
    //
    
    
      fill("cornsilk");
    circle(100, 288, 29);
    fill("#262626");
    circle(97, 288, 28);
  
    fill("cornsilk");
    circle(100, 268, 19);
    fill("#262626");
    circle(97, 268, 18);
    
    fill("cornsilk");
    circle(100, 253, 9);
    fill("#262626");
    circle(97, 253, 8);
   
    fill("cornsilk");
    circle(100, 244, 6);
    fill("#262626"); 
    circle(97, 244, 5);
    

      fill("cornsilk");
    circle(300, 288, 29);
    fill("#262626");
    circle(303, 288, 28);    
    
    fill("cornsilk");
    circle(300, 268, 19);
    fill("#262626");
    circle(303, 268, 18);
    
    fill("cornsilk");
    circle(300, 253, 9);
    fill("#262626");
    circle(303, 253, 8);
    
    fill("cornsilk");
    circle(300, 244, 6);
    fill("#262626");
    circle(303, 244, 5);    


    //
    //
    //
    //
    //
    
    
      fill("cornsilk");
    circle(-16, 273, 60);
    fill("#262626");
    circle(-19, 273, 59);
    
    
      fill("cornsilk");
    circle(50, 278, 48);
    fill("#262626");
    circle(47, 278, 47);
    
    fill("cornsilk");
    circle(50, 241, 29);
    fill("#262626");
    circle(47, 241, 28);
    
    fill("cornsilk");
    circle(50, 218, 19);
    fill("#262626");
    circle(47, 218, 18);
    
    fill("cornsilk");
    circle(50, 203, 9);
    fill("#262626");
    circle(47, 203, 8);
    
    fill("cornsilk");
    circle(50, 194, 6);
    fill("#262626"); 
    circle(47, 194, 5);
    

    
      fill("cornsilk");
    circle(416, 273, 60);
    fill("#262626");
    circle(419, 273, 59);
    
      fill("cornsilk");
    circle(350, 278, 48);
    fill("#262626");
    circle(353, 278, 47);    
    
    fill("cornsilk");
    circle(350, 241, 29);
    fill("#262626");
    circle(353, 241, 28);    
    
    fill("cornsilk");
    circle(350, 218, 19);
    fill("#262626");
    circle(353, 218, 18);
    
    fill("cornsilk");
    circle(350, 203, 9);
    fill("#262626");
    circle(353, 203, 8);
    
    fill("cornsilk");
    circle(350, 194, 6);
    fill("#262626");
    circle(353, 194, 5);    
   
    filter(BLUR, 2);
}

function gyntColumns8(){
    background ("#540101")
    fill("#c5270f"); 
    circle(200, 250, 680);
    fill("#de2d12")
    circle(200, 270, 530);
    fill("#f23113")
    circle(200, 270, 465);
    fill("#f5600a")
    circle(200, 270, 385);
    fill("#f78400")
    circle(200, 270, 325);
    fill("#fa9702")
    circle(200, 270, 315);
    fill("#faa702") 
    circle(200, 275, 295);
    fill("#fab802")
    circle(200, 275, 275);
    filter(BLUR, 5);
    
    //
    
    
    fill("#fffae8");
    circle(185, 295, 8);
    fill("#262626");
    circle(182, 295, 7);

    fill("#fffae8");
    circle(215, 295, 8);
    fill("#262626");
    circle(218, 295, 7);
    
    //
    //
    

    fill("cornsilk");
    circle(165, 295, 10);
    fill("#262626");
    circle(162, 295, 9);
   
    fill("cornsilk");
    circle(165, 288, 6);
    fill("#262626");
    circle(162, 288, 5);
    
    fill("cornsilk");
    circle(235, 295, 10);
    fill("#262626");
    circle(238, 295, 9);
    
    fill("cornsilk");
    circle(235, 288, 6);
    fill("#262626");
    circle(238, 288, 5);
    
    //
    //
    //
    
      fill("cornsilk");
    circle(135, 293, 20);
    fill("#262626");
    circle(132, 293, 19);
   
    fill("cornsilk");
    circle(135, 278, 10);
    fill("#262626");
    circle(132, 278, 9);
    
    fill("cornsilk");
    circle(135, 269, 6);
    fill("#262626"); 
    circle(132, 269, 5);    
    
      fill("cornsilk");
    circle(265, 293, 20);
    fill("#262626");
    circle(268, 293, 19);
    
    fill("cornsilk");
    circle(265, 278, 10);
    fill("#262626");
    circle(268, 278, 9);
   
    fill("cornsilk");
    circle(265, 269, 6);
    fill("#262626");
    circle(268, 269, 5);

  
    //
    //
    //
    //
    

      fill("cornsilk");
    circle(95, 288, 30);
    fill("#262626");
    circle(92, 288, 29);
    
      fill("cornsilk");
    circle(95, 268, 20);
    fill("#262626");
    circle(92, 268, 19);
    
    fill("cornsilk");
    circle(95, 253, 10);
    fill("#262626");
    circle(92, 253, 9);
    
    fill("cornsilk");
    circle(95, 244, 6);
    fill("#262626"); 
    circle(92, 244, 5);    


      fill("cornsilk");
    circle(305, 288, 30);
    fill("#262626");
    circle(308, 288, 29);    
    
    fill("cornsilk");
    circle(305, 268, 20);
    fill("#262626");
    circle(308, 268, 19);
    
    fill("cornsilk");
    circle(305, 253, 10);
    fill("#262626");
    circle(308, 253, 9);
    
    fill("cornsilk");
    circle(305, 244, 6);
    fill("#262626");
    circle(308, 244, 5);
    

    //
    //
    //
    //
    //
    

      fill("cornsilk");
    circle(35, 278, 50);
    fill("#262626");
    circle(32, 278, 49);
    
    fill("cornsilk");
    circle(35, 241, 30);
    fill("#262626");
    circle(32, 241, 29);
  
    fill("cornsilk");
    circle(35, 218, 20);
    fill("#262626");
    circle(32, 218, 19);
    
    fill("cornsilk");
    circle(35, 203, 10);
    fill("#262626");
    circle(32, 203, 9);
    
    fill("cornsilk");
    circle(35, 194, 6);
    fill("#262626"); 
    circle(32, 194, 5);    


      fill("cornsilk");
    circle(365, 278, 50);
    fill("#262626");
    circle(368, 278, 49);    

    fill("cornsilk");
    circle(365, 241, 30);
    fill("#262626");
    circle(368, 241, 29);    
    
    fill("cornsilk");
    circle(365, 218, 20);
    fill("#262626");
    circle(368, 218, 19);
    
    fill("cornsilk");
    circle(365, 203, 10);
    fill("#262626");
    circle(368, 203, 9);
    
    fill("cornsilk");
    circle(365, 194, 6);
    fill("#262626");
    circle(368, 194, 5);
    
    filter(BLUR, 2);
}


// editing columns9 




function gyntColumns9(){
    background ("#540101")
    fill("#c5270f"); 
    circle(200, 250, 720);
    fill("#de2d12")
    circle(200, 270, 570);
    fill("#f23113")
    circle(200, 270, 505);
    fill("#f5600a")
    circle(200, 270, 425);
    fill("#f78400")
    circle(200, 270, 345);
    fill("#fa9702")
    circle(200, 270, 335);
    fill("#faa702") 
    circle(200, 275, 315);
    fill("#fab802")
    circle(200, 275, 295);
    filter(BLUR, 5);
    
//

    fill("#cornsilk");
    circle(190, 295, 7);
    
    fill("#262626");
    circle(187, 295, 5);
    
    fill("#cornsilk");
    circle(210, 295, 7);
    
    fill("#262626");
    circle(213, 295, 5);
    
    
    //
    //
    
    fill("#cornsilk");
    circle(170, 295, 10);
    fill("#262626");
    circle(167, 295, 8);
   
    fill("#cornsilk");
    circle(170, 288, 7);
    fill("#262626");
    circle(167, 288, 5);
    
    fill("#cornsilk");
    circle(230, 295, 10);
    fill("#262626");
    circle(233, 295, 8);
    
    fill("#cornsilk");
    circle(230, 288, 7);
    fill("#262626");
    circle(233, 288, 5);

    
    //
    //
    //
    

      fill("#cornsilk");
    circle(140, 293, 19);
    fill("#262626");
    circle(137, 293, 18);
    
    fill("#cornsilk");
    circle(140, 278, 9);
    fill("#262626");
    circle(137, 278, 8);
    
    fill("#cornsilk");
    circle(140, 269, 6);
    fill("#262626"); 
    circle(137, 269, 5);
    
    fill("cornsilk");
    circle(260, 293, 19);
    fill("#262626");
    circle(263, 293, 18);
    
    fill("#cornsilk");
    circle(260, 278, 9);
    fill("#262626");
    circle(263, 278, 8);
    
    fill("#cornsilk");
    circle(260, 269, 6);
    fill("#262626");
    circle(263, 269, 5);
  
    //
    //
    //
    //
    
    fill("#cornsilk");
    circle(100, 288, 29);
    fill("#262626");
    circle(97, 288, 28);
  
    fill("#cornsilk");
    circle(100, 268, 19);
    fill("#262626");
    circle(97, 268, 18);
    
    fill("#cornsilk");
    circle(100, 253, 9);
    fill("#262626");
    circle(97, 253, 8);
   
    fill("#cornsilk");
    circle(100, 244, 6);
    fill("#262626"); 
    circle(97, 244, 5);
    
    fill("#cornsilk");
    circle(300, 288, 29);
    fill("#262626");
    circle(303, 288, 28);    
    
    fill("#cornsilk");
    circle(300, 268, 19);
    fill("#262626");
    circle(303, 268, 18);
    
    fill("#cornsilk");
    circle(300, 253, 9);
    fill("#262626");
    circle(303, 253, 8);
    
    fill("#cornsilk");
    circle(300, 244, 6);
    fill("#262626");
    circle(303, 244, 5);    

    //
    //
    //
    //
    //
    
    fill("#cornsilk");
    circle(-16, 273, 60);
    fill("#262626");
    circle(-19, 273, 59);
    
    fill("#cornsilk");
    circle(50, 278, 48);
    fill("#262626");
    circle(47, 278, 47);
    
    fill("#cornsilk");
    circle(50, 241, 29);
    fill("#262626");
    circle(47, 241, 28);
    
    fill("#cornsilk");
    circle(50, 218, 19);
    fill("#262626");
    circle(47, 218, 18);
    
    fill("#cornsilk");
    circle(50, 203, 9);
    fill("#262626");
    circle(47, 203, 8);
    
    fill("#cornsilk");
    circle(50, 194, 6);
    fill("#262626"); 
    circle(47, 194, 5);
    
    fill("#cornsilk");
    circle(416, 273, 60);
    fill("#262626");
    circle(419, 273, 59);
    
    fill("#cornsilk");
    circle(350, 278, 48);
    fill("#262626");
    circle(353, 278, 47);    
    
    fill("#cornsilk");
    circle(350, 241, 29);
    fill("#262626");
    circle(353, 241, 28);    
    
    fill("#cornsilk");
    circle(350, 218, 19);
    fill("#262626");
    circle(353, 218, 18);
    
    fill("#cornsilk");
    circle(350, 203, 9);
    fill("#262626");
    circle(353, 203, 8);
    
    fill("#cornsilk");
    circle(350, 194, 6);
    fill("#262626");
    circle(353, 194, 5);    
   
    filter(BLUR, 2);
}

function gyntColumns10(){
       background ("#540101")
    fill("#c5270f"); 
    circle(200, 250, 720);
    fill("#de2d12")
    circle(200, 270, 610);
    fill("#f23113")
    circle(200, 270, 545);
    fill("#f5600a")
    circle(200, 270, 465);
    fill("#f78400")
    circle(200, 270, 385);
    fill("#fa9702")
    circle(200, 270, 375);
    fill("#faa702") 
    circle(200, 275, 355);
    fill("#fab802")
    circle(200, 275, 335);
    filter(BLUR, 5);
    
    //
    
    fill("cornsilk");
    circle(185, 295, 7);
    fill("#262626");
    circle(182, 295, 5);

    fill("cornsilk");
    circle(215, 295, 7);
    fill("#262626");
    circle(218, 295, 5);
    
    //
    //
    

    fill("cornsilk");
    circle(165, 295, 10);
    fill("#262626");
    circle(162, 295, 8);
   
    fill("cornsilk");
    circle(165, 288, 7);
    fill("#262626");
    circle(162, 288, 5);
    
    fill("cornsilk");
    circle(235, 295, 10);
    fill("#262626");
    circle(238, 295, 8);
   
    fill("cornsilk");
    circle(235, 288, 7);
    fill("#262626");
    circle(238, 288, 5);
    
    //
    //
    //
    
    fill("cornsilk");
    circle(135, 293, 20);
    fill("#262626");
    circle(132, 293, 18);
   
    fill("cornsilk");
    circle(135, 278, 10);
    fill("#262626");
    circle(132, 278, 8);
    
    fill("cornsilk");
    circle(135, 269, 7);
    fill("#262626"); 
    circle(132, 269, 5);    
    
    fill("cornsilk");
    circle(265, 293, 20);
    fill("#262626");
    circle(268, 293, 18);
    
    fill("cornsilk");
    circle(265, 278, 10);
    fill("#262626");
    circle(268, 278, 8);
   
    fill("cornsilk");
    circle(265, 269, 7);
    fill("#262626");
    circle(268, 269, 5);
  
    //
    //
    //
    //
    
    fill("cornsilk");
    circle(95, 288, 30);
    fill("#262626");
    circle(92, 288, 29);
    
    fill("cornsilk");
    circle(95, 268, 20);
    fill("#262626");
    circle(92, 268, 19);
    
    fill("cornsilk");
    circle(95, 253, 10);
    fill("#262626");
    circle(92, 253, 9);
    
    fill("cornsilk");
    circle(95, 244, 6);
    fill("#262626"); 
    circle(92, 244, 5);    

    fill("cornsilk");
    circle(305, 288, 30);
    fill("#262626");
    circle(308, 288, 29);    
   
    fill("cornsilk");
    circle(305, 268, 20);
    fill("#262626");
    circle(308, 268, 19);
    
    fill("cornsilk");
    circle(305, 253, 10);
    fill("#262626");
    circle(308, 253, 9);
    
    fill("cornsilk");
    circle(305, 244, 6);
    fill("#262626");
    circle(308, 244, 5);  

    //
    //
    //
    //
    //
    

    fill("cornsilk");
    circle(35, 278, 50);
    fill("#262626");
    circle(32, 278, 49);
    
    fill("cornsilk");
    circle(35, 241, 30);
    fill("#262626");
    circle(32, 241, 29);
  
    fill("cornsilk");
    circle(35, 218, 20);
    fill("#262626");
    circle(32, 218, 19);
   
    fill("cornsilk");
    circle(35, 203, 10);
    fill("#262626");
    circle(32, 203, 9);
    
    fill("cornsilk");
    circle(35, 194, 6);
    fill("#262626"); 
    circle(32, 194, 5);    

    fill("cornsilk");
    circle(365, 278, 50);
    fill("#262626");
    circle(368, 278, 49);    

    fill("cornsilk");
    circle(365, 241, 30);
    fill("#262626");
    circle(368, 241, 29);    
    
    fill("cornsilk");
    circle(365, 218, 20);
    fill("#262626");
    circle(368, 218, 19);
    
    fill("cornsilk");
    circle(365, 203, 10);
    fill("#262626");
    circle(368, 203, 9);
    
    fill("cornsilk");
    circle(365, 194, 6);
    fill("#262626");
    circle(368, 194, 5);
   
    filter(BLUR, 2);
}

function gyntColumns11(){
    background ("#540101")
    fill("#c5270f"); 
    circle(200, 250, 720);
    fill("#de2d12")
    circle(200, 270, 650);
    fill("#f23113")
    circle(200, 270, 585);
    fill("#f5600a")
    circle(200, 270, 505);
    fill("#f78400")
    circle(200, 270, 425);
    fill("#fa9702")
    circle(200, 270, 395);
    fill("#faa702") 
    circle(200, 275, 375);
    fill("#fab802")
    circle(200, 275, 355);
    filter(BLUR, 5);
    
//

    fill("cornsilk");
    circle(190, 295, 7);
    
    fill("#262626");
    circle(187, 295, 5);
    
    fill("cornsilk");
    circle(210, 295, 7);
    
    fill("#262626");
    circle(213, 295, 5);
    
    
    //
    //
    
    fill("cornsilk");
    circle(170, 295, 10);
    fill("#262626");
    circle(167, 295, 8);
   
    fill("cornsilk");
    circle(170, 288, 7);
    fill("#262626");
    circle(167, 288, 5);
    
    fill("cornsilk");
    circle(230, 295, 10);
    fill("#262626");
    circle(233, 295, 8);
    
    fill("cornsilk");
    circle(230, 288, 7);
    fill("#262626");
    circle(233, 288, 5);
    
    //
    //
    //

    fill("cornsilk");
    circle(140, 293, 20);
    fill("#262626");
    circle(137, 293, 18);
    
    fill("cornsilk");
    circle(140, 278, 10);
    fill("#262626");
    circle(137, 278, 8);
    
    fill("cornsilk");
    circle(140, 269, 7);
    fill("#262626"); 
    circle(137, 269, 5);
    
    fill("cornsilk");
    circle(260, 293, 20);
    fill("#262626");
    circle(263, 293, 18);
    
    fill("cornsilk");
    circle(260, 278, 10);
    fill("#262626");
    circle(263, 278, 8);
    
    fill("cornsilk");
    circle(260, 269, 7);
    fill("#262626");
    circle(263, 269, 5);
  
    //
    //
    //
    //
    
    fill("cornsilk");
    circle(100, 288, 30);
    fill("#262626");
    circle(97, 288, 28);
  
    fill("cornsilk");
    circle(100, 268, 20);
    fill("#262626");
    circle(97, 268, 18);
    
    fill("cornsilk");
    circle(100, 253, 10);
    fill("#262626");
    circle(97, 253, 8);
   
    fill("cornsilk");
    circle(100, 244, 7);
    fill("#262626"); 
    circle(97, 244, 5);
    
    fill("cornsilk");
    circle(300, 288, 30);
    fill("#262626");
    circle(303, 288, 28);    
    
    fill("cornsilk");
    circle(300, 268, 20);
    fill("#262626");
    circle(303, 268, 18);
    
    fill("cornsilk");
    circle(300, 253, 10);
    fill("#262626");
    circle(303, 253, 8);
    
    fill("cornsilk");
    circle(300, 244, 7);
    fill("#262626");
    circle(303, 244, 5);    

    //
    //
    //
    //
    //
    
    fill("cornsilk");
    circle(-16, 273, 60);
    fill("#262626");
    circle(-19, 273, 59);
    
    fill("cornsilk");
    circle(50, 278, 48);
    fill("#262626");
    circle(47, 278, 47);
    
    fill("cornsilk");
    circle(50, 241, 29);
    fill("#262626");
    circle(47, 241, 28);
    
    fill("cornsilk");
    circle(50, 218, 19);
    fill("#262626");
    circle(47, 218, 18);
    
    fill("cornsilk");
    circle(50, 203, 9);
    fill("#262626");
    circle(47, 203, 8);
    
    fill("cornsilk");
    circle(50, 194, 6);
    fill("#262626"); 
    circle(47, 194, 5);
    
    fill("cornsilk");
    circle(416, 273, 60);
    fill("#262626");
    circle(419, 273, 59);
    
    fill("cornsilk");
    circle(350, 278, 48);
    fill("#262626");
    circle(353, 278, 47);    
    
    fill("cornsilk");
    circle(350, 241, 29);
    fill("#262626");
    circle(353, 241, 28);    
    
    fill("cornsilk");
    circle(350, 218, 19);
    fill("#262626");
    circle(353, 218, 18);
    
    fill("cornsilk");
    circle(350, 203, 9);
    fill("#262626");
    circle(353, 203, 8);
    
    fill("cornsilk");
    circle(350, 194, 6);
    fill("#262626");
    circle(353, 194, 5);    
   
    filter(BLUR, 2);
}

function gyntColumns12(){
    background ("#540101")
    fill("#de2d12")
    circle(200, 270, 690);
    fill("#f23113")
    circle(200, 270, 625);
    fill("#f5600a")
    circle(200, 270, 545);
    fill("#f78400")
    circle(200, 270, 465);
    fill("#fa9702")
    circle(200, 270, 415);
    fill("#faa702") 
    circle(200, 275, 395);
    fill("#fab802")
    circle(200, 275, 375);
    filter(BLUR, 5);
    
    //
    
    fill("cornsilk");
    circle(185, 295, 7);
    fill("#262626");
    circle(182, 295, 5);

    fill("cornsilk");
    circle(215, 295, 7);
    fill("#262626");
    circle(218, 295, 5);
    
    //
    //

    fill("cornsilk");
    circle(165, 295, 10);
    fill("#262626");
    circle(162, 295, 8);
    
    fill("cornsilk");
    circle(165, 288, 7);
    fill("#262626");
    circle(162, 288, 5);
    
    fill("cornsilk");
    circle(235, 295, 10);
    fill("#262626");
    circle(238, 295, 8);
   
    fill("cornsilk");
    circle(235, 288, 7);
    fill("#262626");
    circle(238, 288, 5);
    
    //
    //
    //
    
    fill("cornsilk");
    circle(135, 293, 20);
    fill("#262626");
    circle(132, 293, 18);
   
    fill("cornsilk");
    circle(135, 278, 10);
    fill("#262626");
    circle(132, 278, 8);
    
    fill("cornsilk");
    circle(135, 269, 7);
    fill("#262626"); 
    circle(132, 269, 5);    
    
    fill("cornsilk");
    circle(265, 293, 20);
    fill("#262626");
    circle(268, 293, 18);
    
    fill("cornsilk");
    circle(265, 278, 10);
    fill("#262626");
    circle(268, 278, 8);
   
    fill("cornsilk");
    circle(265, 269, 7);
    fill("#262626");
    circle(268, 269, 5);

    //
    //
    //
    //
    
    fill("cornsilk");
    circle(95, 288, 30);
    fill("#262626");
    circle(92, 288, 28);
    
    fill("cornsilk");
    circle(95, 268, 20);
    fill("#262626");
    circle(92, 268, 18);
    
    fill("cornsilk");
    circle(95, 253, 10);
    fill("#262626");
    circle(92, 253, 8);
    
    fill("cornsilk");
    circle(95, 244, 7);
    fill("#262626"); 
    circle(92, 244, 5);    

    fill("cornsilk");
    circle(305, 288, 30);
    fill("#262626");
    circle(308, 288, 28);    
   
    fill("cornsilk");
    circle(305, 268, 20);
    fill("#262626");
    circle(308, 268, 18);
    
    fill("cornsilk");
    circle(305, 253, 10);
    fill("#262626");
    circle(308, 253, 8);
    
    fill("cornsilk");
    circle(305, 244, 7);
    fill("#262626");
    circle(308, 244, 5);  

    //
    //
    //
    //
    //
    
    fill("cornsilk");
    circle(35, 278, 50);
    fill("#262626");
    circle(32, 278, 48);
    
    fill("cornsilk");
    circle(35, 241, 30);
    fill("#262626");
    circle(32, 241, 28);
  
    fill("cornsilk");
    circle(35, 218, 20);
    fill("#262626");
    circle(32, 218, 18);
   
    fill("cornsilk");
    circle(35, 203, 10);
    fill("#262626");
    circle(32, 203, 8);
    
    fill("cornsilk");
    circle(35, 194, 6);
    fill("#262626"); 
    circle(32, 194, 4);    

    fill("cornsilk");
    circle(365, 278, 50);
    fill("#262626");
    circle(368, 278, 48);    

    fill("cornsilk");
    circle(365, 241, 30);
    fill("#262626");
    circle(368, 241, 28);    
    
    fill("cornsilk");
    circle(365, 218, 20);
    fill("#262626");
    circle(368, 218, 18);
    
    fill("cornsilk");
    circle(365, 203, 10);
    fill("#262626");
    circle(368, 203, 8);
    
    fill("cornsilk");
    circle(365, 194, 6);
    fill("#262626");
    circle(368, 194, 4);
    
    filter(BLUR, 2);
}

function gyntColumns13(){ 
    background ("#540101")
    fill("#de2d12")
    circle(200, 270, 740);
    fill("#f23113")
    circle(200, 270, 665);
    fill("#f5600a")
    circle(200, 270, 585);
    fill("#f78400")
    circle(200, 270, 505);
    fill("#fa9702")
    circle(200, 270, 435);
    fill("#faa702") 
    circle(200, 275, 415);
    fill("#fab802")
    circle(200, 275, 375);
    filter(BLUR, 5);
    
    //
    
    fill("cornsilk");
    circle(190, 295, 7);
    
    fill("#262626");
    circle(187, 295, 5);
    
    fill("cornsilk");
    circle(210, 295, 7);
    
    fill("#262626");
    circle(213, 295, 5);
    
    //
    //
    
    fill("cornsilk");
    circle(170, 295, 10);
    fill("#262626");
    circle(167, 295, 8);
   
    fill("cornsilk");
    circle(170, 288, 7);
    fill("#262626");
    circle(167, 288, 5);
    
    fill("cornsilk");
    circle(230, 295, 10);
    fill("#262626");
    circle(233, 295, 8);
    
    fill("cornsilk");
    circle(230, 288, 7);
    fill("#262626");
    circle(233, 288, 5);

    //
    //
    //
    
    fill("cornsilk");
    circle(140, 293, 20);
    fill("#262626");
    circle(137, 293, 18);
    
    fill("cornsilk");
    circle(140, 278, 10);
    fill("#262626");
    circle(137, 278, 8);
    
    fill("cornsilk");
    circle(140, 269, 7);
    fill("#262626"); 
    circle(137, 269, 5);
    
    fill("cornsilk");
    circle(260, 293, 20);
    fill("#262626");
    circle(263, 293, 18);
    
    fill("cornsilk");
    circle(260, 278, 10);
    fill("#262626");
    circle(263, 278, 8);
    
    fill("cornsilk");
    circle(260, 269, 7);
    fill("#262626");
    circle(263, 269, 5);
  
    //
    //
    //
    //
    
    fill("cornsilk");
    circle(100, 288, 30);
    fill("#262626");
    circle(97, 288, 28);
  
    fill("cornsilk");
    circle(100, 268, 20);
    fill("#262626");
    circle(97, 268, 18);
    
    fill("cornsilk");
    circle(100, 253, 10);
    fill("#262626");
    circle(97, 253, 8);
   
    fill("cornsilk");
    circle(100, 244, 7);
    fill("#262626"); 
    circle(97, 244, 5);
    
    fill("cornsilk");
    circle(300, 288, 30);
    fill("#262626");
    circle(303, 288, 28);    
    
    fill("cornsilk");
    circle(300, 268, 20);
    fill("#262626");
    circle(303, 268, 18);
    
    fill("cornsilk");
    circle(300, 253, 10);
    fill("#262626");
    circle(303, 253, 8);
    
    fill("cornsilk");
    circle(300, 244, 7);
    fill("#262626");
    circle(303, 244, 5);    

    //
    //
    //
    //
    //
    
    fill("cornsilk");
    circle(-16, 273, 61);
    fill("#262626");
    circle(-19, 273, 59);
    
    fill("cornsilk");
    circle(50, 278, 49);
    fill("#262626");
    circle(47, 278, 47);
    
    fill("cornsilk");
    circle(50, 241, 30);
    fill("#262626");
    circle(47, 241, 28);
    
    fill("cornsilk");
    circle(50, 218, 20);
    fill("#262626");
    circle(47, 218, 18);
    
    fill("cornsilk");
    circle(50, 203, 10);
    fill("#262626");
    circle(47, 203, 8);
    
    fill("cornsilk");
    circle(50, 194, 7);
    fill("#262626"); 
    circle(47, 194, 5);
    
    fill("cornsilk");
    circle(416, 273, 61);
    fill("#262626");
    circle(419, 273, 59);
    
    fill("cornsilk");
    circle(350, 278, 49);
    fill("#262626");
    circle(353, 278, 47);    
    
    fill("cornsilk");
    circle(350, 241, 30);
    fill("#262626");
    circle(353, 241, 28);    
    
    fill("cornsilk");
    circle(350, 218, 20);
    fill("#262626");
    circle(353, 218, 18);
    
    fill("cornsilk");
    circle(350, 203, 10);
    fill("#262626");
    circle(353, 203, 8);
    
    fill("cornsilk");
    circle(350, 194, 7);
    fill("#262626");
    circle(353, 194, 5);    
   
    filter(BLUR, 2);
}

function gyntColumns14(){
      background ("#540101")
    fill("#de2d12")
    circle(200, 270, 760);
    fill("#f23113")
    circle(200, 270, 685);
    fill("#f5600a")
    circle(200, 270, 605);
    fill("#f78400")
    circle(200, 270, 525);
    fill("#fa9702")
    circle(200, 270, 455);
    fill("#faa702") 
    circle(200, 275, 435);
    fill("#fab802")
    circle(200, 275, 395);
    filter(BLUR, 6);
    
    //
    
    fill("cornsilk");
    circle(185, 295, 7);
    fill("#3b3b3b");
    circle(182, 295, 4);

    fill("cornsilk");
    circle(215, 295, 7);
    fill("#3b3b3b");
    circle(218, 295, 4);
    
    //
    //

    fill("cornsilk");
    circle(165, 295, 10);
    fill("#3b3b3b");
    circle(162, 295, 7);
    
    fill("cornsilk");
    circle(165, 288, 7);
    fill("#3b3b3b");
    circle(162, 288, 4);
    
    fill("cornsilk");
    circle(235, 295, 10);
    fill("#262626");
    circle(238, 295, 7);
   
    fill("cornsilk");
    circle(235, 288, 7);
    fill("#262626");
    circle(238, 288, 4);
    
    //
    //
    //
    
    fill("cornsilk");
    circle(135, 293, 20);
    fill("#262626");
    circle(132, 293, 18);
   
    fill("cornsilk");
    circle(135, 278, 10);
    fill("#262626");
    circle(132, 278, 8);
    
    fill("cornsilk");
    circle(135, 269, 7);
    fill("#262626"); 
    circle(132, 269, 5);    
    
    fill("cornsilk");
    circle(265, 293, 20);
    fill("#262626");
    circle(268, 293, 18);
    
    fill("cornsilk");
    circle(265, 278, 10);
    fill("#262626");
    circle(268, 278, 8);
   
    fill("cornsilk");
    circle(265, 269, 7);
    fill("#262626");
    circle(268, 269, 5);

    //
    //
    //
    //
    
    fill("cornsilk");
    circle(95, 288, 30);
    fill("#262626");
    circle(92, 288, 28);
    
    fill("cornsilk");
    circle(95, 268, 20);
    fill("#262626");
    circle(92, 268, 18);
    
    fill("cornsilk");
    circle(95, 253, 10);
    fill("#262626");
    circle(92, 253, 8);
    
    fill("cornsilk");
    circle(95, 244, 7);
    fill("#262626"); 
    circle(92, 244, 5);    

    fill("cornsilk");
    circle(305, 288, 30);
    fill("#262626");
    circle(308, 288, 28);    
   
    fill("cornsilk");
    circle(305, 268, 20);
    fill("#262626");
    circle(308, 268, 18);
    
    fill("cornsilk");
    circle(305, 253, 10);
    fill("#262626");
    circle(308, 253, 8);
    
    fill("cornsilk");
    circle(305, 244, 7);
    fill("#262626");
    circle(308, 244, 5);  

    //
    //
    //
    //
    //
    
    fill("cornsilk");
    circle(35, 278, 50);
    fill("#262626");
    circle(32, 278, 48);
    
    fill("cornsilk");
    circle(35, 241, 30);
    fill("#262626");
    circle(32, 241, 28);
  
    fill("cornsilk");
    circle(35, 218, 20);
    fill("#262626");
    circle(32, 218, 18);
   
    fill("cornsilk");
    circle(35, 203, 10);
    fill("#262626");
    circle(32, 203, 8);
    
    fill("cornsilk");
    circle(35, 194, 6);
    fill("#262626"); 
    circle(32, 194, 4);    

    fill("cornsilk");
    circle(365, 278, 50);
    fill("#262626");
    circle(368, 278, 48);    

    fill("cornsilk");
    circle(365, 241, 30);
    fill("#262626");
    circle(368, 241, 28);    
    
    fill("cornsilk");
    circle(365, 218, 20);
    fill("#262626");
    circle(368, 218, 18);
    
    fill("cornsilk");
    circle(365, 203, 10);
    fill("#262626");
    circle(368, 203, 8);
    
    fill("cornsilk");
    circle(365, 194, 6);
    fill("#262626");
    circle(368, 194, 4);
    
    filter(BLUR, 2);
}

function gyntColumns15(){
  
}

function gyntColumns16(){}